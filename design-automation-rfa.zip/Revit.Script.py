import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
import System
import os
import sys

def create_new_project_template(app):
    """Create a new project from default template"""
    try:
        # Get the default project template
        template_path = None

        # Create a new document from default template
        doc = app.NewProjectDocument(UnitSystem.Imperial)

        return doc
    except Exception as e:
        print(f"Error creating new project: {e}")
        sys.exit(1)

def load_family(doc, rfa_path):
    """Load RFA family into the document"""
    try:
        # Start a transaction
        with Transaction(doc, "Load Family") as trans:
            trans.Start()

            # Load the family
            family_loaded = doc.LoadFamily(rfa_path)

            if not family_loaded:
                print("Failed to load family")
                trans.RollBack()
                return None

            trans.Commit()

        # Get the loaded family
        collector = FilteredElementCollector(doc).OfClass(Family)
        families = list(collector)

        if families:
            return families[-1].Id  # Return the last loaded family's ID

        return None

    except Exception as e:
        print(f"Error loading family: {e}")
        return None

def place_family_instance(doc, family_id, location_point):
    """Place an instance of the loaded family"""
    try:
        # Start a transaction
        with Transaction(doc, "Place Family Instance") as trans:
            trans.Start()

            # Get family symbol
            family = doc.GetElement(family_id)
            if not family:
                print("Family not found")
                trans.RollBack()
                return None

            # Get family symbols
            family_symbols = []
            for symbol_id in family.GetFamilySymbolIds():
                family_symbols.append(doc.GetElement(symbol_id))

            if not family_symbols:
                print("No family symbols found")
                trans.RollBack()
                return None

            # Use the first family symbol
            family_symbol = family_symbols[0]

            # Activate the symbol if not active
            if not family_symbol.IsActive:
                family_symbol.Activate()

            # Place the family instance
            instance = doc.Create.NewFamilyInstance(
                location_point,
                family_symbol,
                StructuralType.NonStructural
            )

            trans.Commit()
            return instance.Id

    except Exception as e:
        print(f"Error placing family instance: {e}")
        return None

def export_to_ifc(doc, output_path):
    """Export the document to IFC format"""
    try:
        # Create IFC export options
        ifc_options = IFCExportOptions()

        # Set basic export options
        ifc_options.FileVersion = IFCVersion.IFC2x3
        ifc_options.ExportRoomsAsSpaces = True
        ifc_options.ExportInternalRevitId = True
        ifc_options.ExportParameterMapping = True

        # Export to IFC
        result = doc.Export(os.path.dirname(output_path),
                           os.path.basename(output_path).replace('.ifc', ''),
                           System.Collections.Generic.ICollection[ElementId](),
                           ifc_options)

        if result:
            print(f"Successfully exported to IFC: {output_path}")
            return True
        else:
            print("IFC export failed")
            return False

    except Exception as e:
        print(f"Error exporting to IFC: {e}")
        return False

def main():
    """Main function for RFA processing"""
    try:
        # Get input arguments from Design Automation
        rfa_input_path = IN[0] if len(IN) > 0 else None
        output_path = OUT[0] if len(OUT) > 0 else None
        family_name = IN[1] if len(IN) > 1 else None

        if not rfa_input_path or not output_path:
            print("Missing required input/output paths")
            sys.exit(1)

        print(f"Processing RFA: {rfa_input_path}")
        print(f"Output path: {output_path}")
        print(f"Family name: {family_name}")

        # Create new project
        doc = create_new_project_template(Application)
        if not doc:
            print("Failed to create new project")
            sys.exit(1)

        print("Created new Revit project")

        # Load the RFA family
        family_id = load_family(doc, rfa_input_path)
        if not family_id:
            print("Failed to load RFA family")
            sys.exit(1)

        print(f"Successfully loaded family: {family_id}")

        # Place family instances (3 instances in a line for better viewing)
        instance_ids = []
        for i in range(3):
            location = XYZ(i * 10, 0, 0)  # Place instances 10 feet apart
            instance_id = place_family_instance(doc, family_id, location)
            if instance_id:
                instance_ids.append(instance_id)
                print(f"Placed family instance {i + 1} at ID: {instance_id}")

        if not instance_ids:
            print("Failed to place any family instances")
            sys.exit(1)

        print(f"Successfully placed {len(instance_ids)} family instances")

        # Save the project first (for verification)
        project_save_path = output_path.replace('.ifc', '.rvt')
        save_options = SaveOptions()
        save_options.OverwriteExistingFile = True

        with Transaction(doc, "Save Project") as trans:
            trans.Start()
            doc.SaveAs(project_save_path, save_options)
            trans.Commit()

        print(f"Saved project as: {project_save_path}")

        # Export to IFC for viewing
        ifc_exported = export_to_ifc(doc, output_path)
        if ifc_exported:
            print("RFA processing completed successfully")
        else:
            print("Warning: IFC export failed, but project saved successfully")

        # Close document
        doc.Close(False)  # Don't save changes again

        print("RFA processing workflow completed")

    except Exception as e:
        print(f"Error in main function: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()